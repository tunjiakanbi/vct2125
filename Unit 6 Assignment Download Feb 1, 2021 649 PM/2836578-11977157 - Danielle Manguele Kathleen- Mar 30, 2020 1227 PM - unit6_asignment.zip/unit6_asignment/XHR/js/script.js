"use strict";
(function(){

    var url="http://api.weatherstack.com/current"
    var apiKey="405acb11863bc312a97b8ffd5009697c";
    var place="Cameroon";
    var httpRequest;
    makeRequest();

    function makeRequest(){
        httpRequest = new XMLHttpRequest();
        httpRequest.onreadystatechange = responseMethod;
        httpRequest.open('GET', url  + apiKey + place);
        httpRequest.send();

    }
    function responseMethod(){
        if (httpRequest.readyState===4){
            if( httpRequest.status===200){
                updateUISuccess(httpRequest.responseText);
            }else{
               updateUIError();
            }
            console.log(httpRequest.responseText);
        }
    }
    function updateUISuccess(responseText){
        var response = JSON.parse(responseText);
        var temp = response.weather[0].main;
        var degC = response.main.temp - 273.15;
        var degCInt= Math.floor(degC);
        var degF= degC * 1.8 + 32;
        var degFInt= Math.floor(degF);
        var weatherBox = document.getElementById("weather");
        weatherBox.innerHTML="<p>" + degCInt + "&#176; C / " + degFInt + "&#176; F </p><p>" + condition + "</p>"


    }
    function updateUIError(){
         var weatherBox= document.getElementById("weather");
         weatherBox.className="hidden";
    }
})();