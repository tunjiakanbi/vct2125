"use strict";
// var search = $("#search").value;
$("#submit").on('click', function (event) {
    event.preventDefault();
    var search = $("#search").val().trim();
    console.log(search);
    runSearch(search);
    // (()=>{search.val() = "";})();
    // $("search").value = "";
    
})

function runSearch(searchs){
// Find all of the objects that are paintings and have the word "rabbit" in the title
var apiEndpointBaseURL = "https://api.harvardartmuseums.org/object";
var queryString = $.param({
    apikey: "7a940fc0-5a62-11ea-b877-8f943796feb8",
    title: searchs,
    classification: "Paintings"
});

$.getJSON(apiEndpointBaseURL + "?" + queryString, function(data) {
   console.log(data); 
  var newArt = data.records[0].primaryimageurl;
//   console.log(newArt); 
  $("#harvard").html(
      '<section><img src="' + newArt + '"/></section>')
});
}


